Nut Bolt Assembly Simulation
============================

Nut and bolt CATIA assembly with source parts, CATProduct file, preview image, and simulation video.

Included CATIA source files:
- Bolt.CATPart
- Nut.CATPart
- Nut_Bolt Assembly.CATProduct
