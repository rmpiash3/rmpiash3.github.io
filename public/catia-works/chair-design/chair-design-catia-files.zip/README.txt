Chair Design
============

Chair model design with CATPart source file and preview render.

Included CATIA source files:
- Chair.CATPart
