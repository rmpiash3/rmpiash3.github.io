clc; clear; close all;

%% Battery parameters
dt = 1;                  % second
t_end = 3600;            % 1 hour
t = 0:dt:t_end;
N = length(t);

Qcap_Ah = 2.3;           % Battery capacity
Qcap = Qcap_Ah * 3600;   % As

R0 = 0.03;
R1 = 0.015;
C1 = 2400;

Rth = 4;
Cth = 500;
Tamb = 25;

%% OCV-SOC lookup table
SOC_table = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
OCV_table = [3.0 3.2 3.3 3.35 3.4 3.45 3.5 3.58 3.65 3.75 4.2];

%% Current profile
I = 2 * ones(1,N);       % 2A discharge

%% True states
SOC_true = zeros(1,N);
Vrc_true = zeros(1,N);
Temp = zeros(1,N);
Vt_meas = zeros(1,N);
Heat = zeros(1,N);

SOC_true(1) = 0.95;
Vrc_true(1) = 0;
Temp(1) = Tamb;

%% EKF initialization
x_hat = [0.90; 0];       % [SOC; Vrc]
P = diag([0.01 0.01]);

Q = diag([1e-7 1e-5]);   % process noise
R = 0.002^2;             % voltage sensor noise

SOC_est = zeros(1,N);
Vrc_est = zeros(1,N);
Vt_est = zeros(1,N);

SOC_est(1) = x_hat(1);
Vrc_est(1) = x_hat(2);

a = exp(-dt/(R1*C1));

%% Live plot setup
figure;

for k = 1:N-1

    %% True battery model
    SOC_true(k+1) = SOC_true(k) - (I(k)*dt)/Qcap;
    SOC_true(k+1) = max(0,min(1,SOC_true(k+1)));

    Vrc_true(k+1) = a*Vrc_true(k) + R1*(1-a)*I(k);

    OCV_true = interp1(SOC_table,OCV_table,SOC_true(k),'linear','extrap');
    Vt_true = OCV_true - Vrc_true(k) - I(k)*R0;

    Vt_meas(k) = Vt_true + 0.002*randn;

    Heat(k) = I(k)^2*R0 + I(k)*Vrc_true(k);

    Temp(k+1) = Temp(k) + dt/Cth*(Heat(k) - (Temp(k)-Tamb)/Rth);

    %% EKF prediction
    SOC_pred = x_hat(1) - (I(k)*dt)/Qcap;
    Vrc_pred = a*x_hat(2) + R1*(1-a)*I(k);

    x_pred = [SOC_pred; Vrc_pred];

    A = [1 0; 
         0 a];

    P_pred = A*P*A' + Q;

    %% EKF measurement update
    OCV_pred = interp1(SOC_table,OCV_table,x_pred(1),'linear','extrap');

    dOCVdSOC = gradient(OCV_table,SOC_table);
    dOCV = interp1(SOC_table,dOCVdSOC,x_pred(1),'linear','extrap');

    V_pred = OCV_pred - x_pred(2) - I(k)*R0;

    H = [dOCV -1];

    K = P_pred*H'/(H*P_pred*H' + R);

    x_hat = x_pred + K*(Vt_meas(k) - V_pred);

    P = (eye(2) - K*H)*P_pred;

    x_hat(1) = max(0,min(1,x_hat(1)));

    SOC_est(k+1) = x_hat(1);
    Vrc_est(k+1) = x_hat(2);
    Vt_est(k) = V_pred;

    %% Live graphs
    if mod(k,20)==0
        subplot(3,1,1)
        plot(t(1:k)/60,SOC_true(1:k)*100,'LineWidth',1.5); hold on;
        plot(t(1:k)/60,SOC_est(1:k)*100,'--','LineWidth',1.5); hold off;
        ylabel('SOC (%)');
        legend('True SOC','EKF SOC');
        grid on;

        subplot(3,1,2)
        plot(t(1:k)/60,Heat(1:k),'LineWidth',1.5);
        ylabel('Heat (W)');
        grid on;

        subplot(3,1,3)
        plot(t(1:k)/60,Temp(1:k),'LineWidth',1.5);
        xlabel('Time (min)');
        ylabel('Temp (°C)');
        grid on;

        drawnow;
    end
end

%% Save results
results = table(t', I', SOC_true'*100, SOC_est'*100, Heat', Temp', ...
    'VariableNames', {'Time_s','Current_A','True_SOC_percent','EKF_SOC_percent','Heat_W','Temperature_C'});

save('EKF_SOC_Thermal_Result.mat','results');
writetable(results,'EKF_SOC_Thermal_Result.csv');

disp('Simulation complete. Result saved as MAT and CSV.');