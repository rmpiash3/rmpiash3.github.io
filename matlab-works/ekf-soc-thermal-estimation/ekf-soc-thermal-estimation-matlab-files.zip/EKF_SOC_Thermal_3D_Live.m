clc; clear; close all;

%% Battery parameters
dt = 1;                  
t_end = 3600;            
t = 0:dt:t_end;
N = length(t);

Qcap_Ah = 2.3;           
Qcap = Qcap_Ah * 3600;   

R0 = 0.03;
R1 = 0.015;
C1 = 2400;

Rth = 4;
Cth = 500;
Tamb = 25;

%% OCV-SOC lookup table
SOC_table = [0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0];
OCV_table = [3.0 3.2 3.3 3.35 3.4 3.45 3.5 3.58 3.65 3.75 4.2];

%% Current profile
I = 2 * ones(1,N);       % 2A discharge

%% True states
SOC_true = zeros(1,N);
Vrc_true = zeros(1,N);
Temp = zeros(1,N);
Vt_meas = zeros(1,N);
Heat = zeros(1,N);

SOC_true(1) = 0.95;
Vrc_true(1) = 0;
Temp(1) = Tamb;

%% EKF initialization
x_hat = [0.90; 0];       % [SOC; Vrc]
P = diag([0.01 0.01]);

Q = diag([1e-7 1e-5]);
R = 0.002^2;

SOC_est = zeros(1,N);
Vrc_est = zeros(1,N);
Vt_est = zeros(1,N);

SOC_est(1) = x_hat(1);
Vrc_est(1) = x_hat(2);

a = exp(-dt/(R1*C1));

%% 3D battery shape
[XC, YC, ZC] = cylinder(1,80);
ZC = ZC * 4;

figure('Name','EKF SOC Thermal Digital Twin','Color','w');

for k = 1:N-1

    %% True battery model
    SOC_true(k+1) = SOC_true(k) - (I(k)*dt)/Qcap;
    SOC_true(k+1) = max(0,min(1,SOC_true(k+1)));

    Vrc_true(k+1) = a*Vrc_true(k) + R1*(1-a)*I(k);

    OCV_true = interp1(SOC_table,OCV_table,SOC_true(k),'linear','extrap');
    Vt_true = OCV_true - Vrc_true(k) - I(k)*R0;

    Vt_meas(k) = Vt_true + 0.002*randn;

    Heat(k) = I(k)^2*R0 + I(k)*Vrc_true(k);

    Temp(k+1) = Temp(k) + dt/Cth*(Heat(k) - (Temp(k)-Tamb)/Rth);

    %% EKF prediction
    SOC_pred = x_hat(1) - (I(k)*dt)/Qcap;
    Vrc_pred = a*x_hat(2) + R1*(1-a)*I(k);

    x_pred = [SOC_pred; Vrc_pred];

    A = [1 0;
         0 a];

    P_pred = A*P*A' + Q;

    %% EKF measurement update
    OCV_pred = interp1(SOC_table,OCV_table,x_pred(1),'linear','extrap');

    dOCVdSOC_table = gradient(OCV_table,SOC_table);
    dOCV = interp1(SOC_table,dOCVdSOC_table,x_pred(1),'linear','extrap');

    V_pred = OCV_pred - x_pred(2) - I(k)*R0;

    H = [dOCV -1];

    K = P_pred*H'/(H*P_pred*H' + R);

    x_hat = x_pred + K*(Vt_meas(k) - V_pred);

    P = (eye(2) - K*H)*P_pred;

    x_hat(1) = max(0,min(1,x_hat(1)));

    SOC_est(k+1) = x_hat(1);
    Vrc_est(k+1) = x_hat(2);
    Vt_est(k) = V_pred;

    %% Live 3D and plots
    if mod(k,20)==0

        clf;

        %% 3D Battery visualization
        subplot(2,3,[1 4])

        tempColor = Temp(k) * ones(size(ZC));

        surf(XC,YC,ZC,tempColor,'EdgeColor','none');
        colormap(jet);
        colorbar;
        caxis([25 60]);

        title(sprintf('3D Battery Thermal View\nTime = %.1f min | Temp = %.2f C | SOC = %.2f %%', ...
            t(k)/60, Temp(k), SOC_est(k)*100));

        xlabel('X');
        ylabel('Y');
        zlabel('Cell Height');

        axis equal;
        axis([-1.5 1.5 -1.5 1.5 0 4]);
        view(40,25);
        grid on;

        %% SOC plot
        subplot(2,3,2)
        plot(t(1:k)/60,SOC_true(1:k)*100,'LineWidth',1.5); hold on;
        plot(t(1:k)/60,SOC_est(1:k)*100,'--','LineWidth',1.5);
        hold off;
        xlabel('Time (min)');
        ylabel('SOC (%)');
        title('SOC Estimation');
        legend('True SOC','EKF SOC');
        grid on;

        %% Heat plot
        subplot(2,3,3)
        plot(t(1:k)/60,Heat(1:k),'LineWidth',1.5);
        xlabel('Time (min)');
        ylabel('Heat (W)');
        title('Heat Generation');
        grid on;

        %% Temperature plot
        subplot(2,3,5)
        plot(t(1:k)/60,Temp(1:k),'LineWidth',1.5);
        xlabel('Time (min)');
        ylabel('Temperature (C)');
        title('Battery Temperature');
        grid on;

        %% Voltage plot
        subplot(2,3,6)
        plot(t(1:k)/60,Vt_meas(1:k),'LineWidth',1.5); hold on;
        plot(t(1:k)/60,Vt_est(1:k),'--','LineWidth',1.5);
        hold off;
        xlabel('Time (min)');
        ylabel('Voltage (V)');
        title('Terminal Voltage');
        legend('Measured','EKF predicted');
        grid on;

        drawnow;
    end
end

%% Final values
fprintf('\nSimulation Complete\n');
fprintf('Final True SOC  = %.2f %%\n', SOC_true(end)*100);
fprintf('Final EKF SOC   = %.2f %%\n', SOC_est(end)*100);
fprintf('Final Temp      = %.2f C\n', Temp(end));
fprintf('Max Temp        = %.2f C\n', max(Temp));
fprintf('Max Heat        = %.4f W\n', max(Heat));

%% Save results
results = table(t', I', SOC_true'*100, SOC_est'*100, Heat', Temp', Vt_meas', Vt_est', ...
    'VariableNames', {'Time_s','Current_A','True_SOC_percent','EKF_SOC_percent', ...
    'Heat_W','Temperature_C','Measured_Voltage_V','EKF_Predicted_Voltage_V'});

save('EKF_SOC_Thermal_3D_Result.mat','results');
writetable(results,'EKF_SOC_Thermal_3D_Result.csv');

disp('Result saved: EKF_SOC_Thermal_3D_Result.mat');
disp('Result saved: EKF_SOC_Thermal_3D_Result.csv');