clc; clear; close all;

Cn = 5;      % Ah
eta = 1;
SOC0 = 0.90;

time = linspace(0,3600,80);      % second
current = linspace(0.5,4,80);    % Ampere

[T, I] = meshgrid(time, current);

SOC = SOC0 - (eta .* I .* T) ./ (3600 * Cn);
SOC = max(0, min(1, SOC));

surf(T/60, I, SOC*100)

xlabel('Time (minute)')
ylabel('Current (A)')
zlabel('SOC (%)')
title('3D SOC Surface using Coulomb Counting')

shading interp
grid on
colorbar
view(45,30)