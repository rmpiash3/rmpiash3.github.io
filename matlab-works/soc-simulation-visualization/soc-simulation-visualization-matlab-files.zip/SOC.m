clc; clear; close all;
Cn = 5;
eta = 1;
soc0 = 0.9;
dt= 1;
T=3600;

time = 0:dt:T;
I=2*ones(size(time));

soc = zeros(size(time));
soc(1) = soc0;
for k =2:length(time)
    soc(k) =soc(k-1)-(eta*I(k)*dt)/(3600*Cn);
end

soc = max(0,min(1, soc));
plot(time/60, soc*100, 'LineWidth',2)
xlabel('Time(Minutes)')
ylabel('soc(%)')
title('SOC Estimation using Coulomb Counting Formula')
grid on