clc; clear; close all;

Cn = 5;          % Ah
eta = 1;
SOC0 = 0.90;
dt = 1;
T = 3600;

time = 0:dt:T;
I = 2 + sin(time/300);   % Variable discharge current

SOC = zeros(size(time));
SOC(1) = SOC0;

figure;
h = animatedline('LineWidth',2);
grid on
xlabel('Time (minute)')
ylabel('Current (A)')
zlabel('SOC (%)')
title('Live 3D SOC Simulation')
view(45,25)

xlim([0 60])
ylim([0 4])
zlim([0 100])

for k = 2:length(time)

    SOC(k) = SOC(k-1) - (eta * I(k) * dt)/(3600 * Cn);
    SOC(k) = max(0, min(1, SOC(k)));

    addpoints(h, time(k)/60, I(k), SOC(k)*100);

    drawnow limitrate
end