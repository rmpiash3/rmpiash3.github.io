Steel Bar Deformation Analysis
==============================

Steel bar deformation study with CATIA analysis setup, CATPart files, and post-processing video.

Included CATIA source files:
- Part1.CATPart
- Steel_Bar_Deformation.CATAnalysis
- Steel_Bar_Deformation.CATPart
