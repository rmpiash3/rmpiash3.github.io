Class 3D Exercises
==================

3D class exercise models with CATPart source files and exercise preview images.

Included CATIA source files:
- EX_02.CATPart
- EX_07.CATPart
- Light.CATPart
