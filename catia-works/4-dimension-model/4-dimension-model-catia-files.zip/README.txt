4 Dimension Model
=================

CATIA V5 4D practice model with rendered preview and CATPart source file.

Included CATIA source files:
- 4D.CATPart
