Exhaust Manifold Design
=======================

Exhaust manifold surface and solid design with CATPart source and multiple preview angles.

Included CATIA source files:
- Exhaust Manifold.CATPart
