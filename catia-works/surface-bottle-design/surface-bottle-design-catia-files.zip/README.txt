Surface Bottle Design
=====================

Bottle model created with CATIA surface design workflow and source CATPart file.

Included CATIA source files:
- RM_Bottle.CATPart
