Class Project 2 Assembly
========================

Second CATIA assembly project with separate parts, final preview, and CATProduct assembly.

Included CATIA source files:
- Assemble.CATProduct
- Back.CATPart
- Bottom.CATPart
- Middle.CATPart
- Top.CATPart
