Class Project 1 Assembly
========================

CATIA assembly project with top, middle, bottom components and CATProduct file.

Included CATIA source files:
- Assemble .CATProduct
- Bottom_1.CATPart
- Bottom_2.CATPart
- Bottom_3.CATPart
- Bottom_4.CATPart
- Middle.CATPart
- Top.CATPart
- Top_1.CATPart
