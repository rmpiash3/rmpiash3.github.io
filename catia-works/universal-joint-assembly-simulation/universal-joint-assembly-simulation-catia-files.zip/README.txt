Universal Joint Assembly Simulation
===================================

Universal joint assembly with shaft, bearing, cross parts, CATProduct file, preview image, and simulation video.

Included CATIA source files:
- Bearing.CATPart
- Cross.CATPart
- Shaft.CATPart
- Universal Joint.CATProduct

Note:
Large AVI animation skipped from repository; compressed MP4 video is included.
