Engine Assembly Simulation
==========================

Engine assembly model with crankshaft, piston, connecting rod files, assembly images, and simulation video.

Included CATIA source files:
- CONNECTING ROD SUB ASSEMBLY.CATProduct
- CONNECTING ROD.CATPart
- CRANK SHAFT.CATPart
- ENGINE ASSEMBLY.CATProduct
- ENGINE BLOCK.CATPart
- PISTON HADE.CATPart
- PISTON PIN.CATPart
- ROD CAP.CATPart
- ROD CAPP.CATPart
