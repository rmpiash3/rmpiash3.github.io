Class Practice Parts
====================

CATIA class practice models including basic parts, design exercises, and preview images.

Included CATIA source files:
- Design One.CATPart
- Design.CATPart
- Part1.CATPart
- Part10.CATPart
- Part11.CATPart
- Part2.CATPart
- Part3.CATPart
- Part4.CATPart
- Part5.CATPart
- Part6.CATPart
- Part7.CATPart
- Part8.CATPart
- Part9.CATPart
