UAV Drone Design
================

UAV drone body concept modeled in CATIA V5 with source CATPart and preview image.

Included CATIA source files:
- UAVs.CATPart
